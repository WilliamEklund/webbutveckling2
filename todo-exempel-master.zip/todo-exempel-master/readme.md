# Vad är det här?

Detta är ett exempel på en todo-app i JavaScript som används i undervsiningen för kursen WEUWEB01 på NTI Gymnasiet Stockholm.
